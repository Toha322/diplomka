from django.urls import path
from .views import (
    home_page, shop_page,product_detail,contact_page,cart,search,wish_list,library
)
urlpatterns = [
    path('', home_page, name='index'),
    path('shop/', shop_page, name='shop'),
    path('library/', library, name='library'),
    path('product/<int:pk>/', product_detail, name='product'),
    path('contact/', contact_page, name='contact'),
    path('cart/', cart, name='cart'),
    path('wishlist/', wish_list, name='wish_list'),
    path('search/', search, name='search'),
    path('shop/genre/<slug:genre_name>/', shop_page, name='shop_by_genre'),
    path('shop/studio/<slug:studio_name>/', shop_page, name='shop_by_studio'),

]