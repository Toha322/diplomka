from django.test import TestCase

# Create your tests here.
from apps.home.models import Genre, Tags, Studio, Game

# Создаем жанры
genres = ["Action", "Adventure", "RPG", "Strategy", "Simulation", "Sports"]
genre_objects = [Genre.objects.create(name=name) for name in genres]

# Создаем теги
tags = ["Multiplayer", "Singleplayer", "Open World", "Indie", "Co-op", "VR"]
tag_objects = [Tags.objects.create(name=name) for name in tags]

# Создаем компании
studios = ["Epic Games", "Valve", "CD Projekt Red", "Ubisoft", "Rockstar Games", "Electronic Arts"]
studio_objects = [Studio.objects.create(name=name) for name in studios]

# Создаем игры
game_data = [
    ("Game A", ["Action"], ["Multiplayer"], ["Epic Games"], 59, 49, 20.5),
    ("Game B", ["Adventure"], ["Singleplayer"], ["Valve"], 69, 59, 30.0),
    ("Game C", ["RPG"], ["Open World"], ["CD Projekt Red"], 79, 69, 50.0),
    ("Game D", ["Strategy"], ["Indie"], ["Ubisoft"], 49, 39, 15.0),
    ("Game E", ["Simulation"], ["Co-op"], ["Rockstar Games"], 99, 89, 25.0),
    ("Game F", ["Sports"], ["VR"], ["Electronic Arts"], 29, 19, 10.0),
    ("Game G", ["Action"], ["VR"], ["Epic Games"], 59, 49, 22.0),
    ("Game H", ["Adventure"], ["Co-op"], ["Valve"], 69, 59, 32.0),
    ("Game I", ["RPG"], ["Indie"], ["CD Projekt Red"], 79, 69, 52.0),
    ("Game J", ["Strategy"], ["Open World"], ["Ubisoft"], 49, 39, 16.0),
    ("Game K", ["Simulation"], ["Singleplayer"], ["Rockstar Games"], 99, 89, 26.0),
    ("Game L", ["Sports"], ["Multiplayer"], ["Electronic Arts"], 29, 19, 12.0),
    ("Game M", ["Action"], ["Singleplayer"], ["Epic Games"], 59, 49, 21.0),
    ("Game N", ["Adventure"], ["Open World"], ["Valve"], 69, 59, 31.0),
    ("Game O", ["RPG"], ["Multiplayer"], ["CD Projekt Red"], 79, 69, 51.0),
    ("Game P", ["Strategy"], ["Co-op"], ["Ubisoft"], 49, 39, 14.0),
    ("Game Q", ["Simulation"], ["VR"], ["Rockstar Games"], 99, 89, 23.0),
    ("Game R", ["Sports"], ["Indie"], ["Electronic Arts"], 29, 19, 11.0),
]

for name, genres, tags, studios, current_price, default_price, size in game_data:
    game = Game.objects.create(
        name=name,
        current_price=current_price,
        default_price=default_price,
        size=size,
    )
    game.genre.set([Genre.objects.get(name=g) for g in genres])
    game.tags.set([Tags.objects.get(name=t) for t in tags])
    game.studio.set([Studio.objects.get(name=s) for s in studios])
    game.save()

print("Данные успешно сгенерированы!")

