from lib2to3.fixes.fix_input import context

from django.db.models import Max, Subquery, OuterRef
from django.shortcuts import render,get_object_or_404,redirect
from . import models
from apps.home.forms import CommentForm

def home_page(request):
    games = models.Game.objects.prefetch_related('genre').all()[:12]

    most_played = models.Game.objects.order_by('-downloads')[:12]


    best = models.Game.objects.order_by('-downloads').first()

    genres = models.Genre.objects.all()


    max_downloads_per_genre = (
        models.Game.objects
        .values('genre')
        .annotate(max_downloads=Max('downloads'))
    )

    # Игры с максимальными скачиваниями по каждому жанру
    most_downloaded = (
        models.Game.objects
        .filter(downloads=Subquery(
            max_downloads_per_genre.filter(genre=OuterRef('genre')).values('max_downloads')
        ))
        .order_by('-downloads', 'genre')
    )[:10]

    # Самая высокая цена
    price = models.Game.objects.order_by('-downloads').values_list('current_price', flat=True).first()


    context = {
        'games': games,
        'most_played': most_played,
        'best': best,
        'genres': genres,
        'most_downloaded': most_downloaded,
        'price': price,
    }

    return render(request, 'home/index.html', context)


def shop_page(request, genre_name=None, studio_name=None):

    genres = models.Genre.objects.all()
    studios = models.Studio.objects.all()


    games = models.Game.objects.all()

    if genre_name:
        genre = get_object_or_404(models.Genre, slug=genre_name)
        games = games.filter(genre=genre)


    if studio_name:
        studio = get_object_or_404(models.Studio, slug=studio_name)
        games = games.filter(studio=studio)


    context = {
        'genres': genres,
        'studios': studios,
        'games': games,
    }
    return render(request, 'home/shop.html', context)

def product_detail(request, pk):


    game = get_object_or_404(models.Game, pk=pk)
    comments = models.Comment.objects.filter(game=game)
    genres = game.genre.all()
    tags = game.tags.all()
    studios = game.studio.all()
    studio = game.studio.first()
    related_games = models.Game.objects.filter(studio__in=studios).exclude(id=game.id)[:5]
    if request.method == 'POST':
        form = CommentForm(data=request.POST)
        if form.is_valid():
            form = form.save(commit=False)
            form.author = request.user
            form.game = game
            form.save()
            return redirect('product', pk=game.pk)

    else:
        form = CommentForm()

    context = {
        'game': game,
        'genres':genres,
        'tags':tags,
        'studios':studios,
        'studio':studio,
        'related_games':related_games,
        'comments': comments,
        'form': form,
    }
    return render(request, 'home/product_detail.html', context)

def contact_page(request):
    return render(request,'home/contact.html')

def cart(request):
    return render(request,'home/cart.html')

def wish_list(request):
    return render(request,'home/wana_buy.html')

def library(request):
    return render(request,'home/library.html')

def search(request):
    query = request.GET.get('searchKeyword')
    games = []
    if query:
        games = models.Game.objects.filter(name__icontains=query)
    if not games:
        message = "Ничего не найдено."
    else:
        message = ""
    context = {
        'games': games,
        'message': message,
    }
    return render(request, 'home/search.html', context)


